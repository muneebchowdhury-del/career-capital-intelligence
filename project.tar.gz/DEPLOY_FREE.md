# Deploy for $0

## What you need

- A free GitHub account.
- A **public repository**. The tracked project data is public market/labor evidence; do not store personal-profile data in the repository.

No custom domain, cloud database, paid scheduler, server or credit card is required for the default architecture.

## One-time setup

1. Create a new public GitHub repository.
2. Upload/push the contents of this project so `README.md`, `.github/`, `docs/`, `data/`, `engine/`, `scripts/`, `tests/`, and `config/` are at repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment → Source**, choose **GitHub Actions**.
5. Open **Actions → Refresh intelligence data → Run workflow**.
6. For the first run, optionally enable **Run every enabled source regardless of cadence**.
7. When the workflow completes, GitHub Pages will show the deployed URL in the `github-pages` environment/deployment step.
8. Bookmark that URL. Future scheduled runs update the evidence store and explicitly redeploy the current static dashboard.

## Normal operation

You do not rebuild the website manually.

Daily scheduled job:

1. determine which sources are due;
2. fetch them with bounded retry/timeouts;
3. append new/revised raw evidence;
4. create reviews for changed/new reports;
5. rebuild the local SQLite database;
6. generate static dashboard JSON;
7. run tests;
8. commit the audit trail;
9. deploy `docs/` to GitHub Pages.

## Reviewing new reports

The dashboard/status files expose pending review IDs. In GitHub:

**Actions → Resolve evidence review → Run workflow**

Provide the review ID and choose `validated`, `published`, `rejected`, `duplicate`, or `superseded`.

## Local database

At any time:

```bash
python scripts/build_site.py
```

creates:

```text
build/intelligence.sqlite
```

The SQLite database contains structured observations, discoveries, reviews, source state, the source registry, run history and recommendation snapshots. It is rebuilt from canonical text files, so there is no proprietary database dependency.

## Backup

The Git repository itself is the primary durable audit history. You can also clone/download the repository and run `python scripts/build_site.py` offline to recreate the SQLite database.
