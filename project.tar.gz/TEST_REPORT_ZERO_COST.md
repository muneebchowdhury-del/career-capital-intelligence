# v5 Zero-Cost — Pre-deployment Test Report

## Verdict

The zero-cost architecture is structurally ready for a live pilot. It has no required paid service and no runtime backend. The remaining unproven items are environmental: real GitHub Actions outbound access to each source, real GitHub Pages deployment, and real-browser E2E after a public deployment URL exists.

## Automated test suite

29 Python behavioral tests pass, including:

- safe wildcard/source matching
- HTTPS/private-address URL policy
- HTML meaningful-text extraction
- source-link extraction
- dashboard schema/reference validation
- Eurostat JSON-stat parsing
- cadence and failed-source retry behavior
- immutable observation revisioning
- batch observation deduplication
- batch discovery deduplication
- evidence review lifecycle
- deterministic/rebuildable SQLite
- source failure isolation
- discovery baseline vs. new-report review behavior
- page-change review behavior
- frontend DOM contract
- generated static JSON integrity
- source registry uniqueness
- no runtime API dependency
- no obvious committed credential patterns
- workflow zero-cost architecture contract
- standalone preview embedding
- repeatable site builds
- queryable local SQLite export

Additional preflight checks passed:

- Python bytecode compilation for engine/scripts
- Node syntax checks for `app-core.js` and `bootstrap.js`
- YAML syntax parsing for all GitHub workflow files
- local static HTTP serving: `/`, `/data/latest.json`, `/data/status.json` returned HTTP 200
- static dashboard dataset contains 16 opportunity nodes

## File-store stress test

Synthetic test:

- 10,000 structured observations
- batch append: ~0.15 s in this environment
- reconstruct current observation set: ~0.08 s
- rebuild complete SQLite database: ~0.07 s
- generated SQLite size: ~2.0 MB

This is comfortably above the project's present data volume. Performance will vary on GitHub-hosted runners, but the architecture has ample headroom for the intended scale.

## Failure behavior verified

- A failed source does not prevent a successful source from persisting its observations.
- A partial run is recorded as partial, not falsely successful.
- A failed source retries on the next daily scheduler pass rather than waiting its normal weekly/monthly cadence.
- A report page change creates a review item instead of changing recommendation scores automatically.
- Discovery establishes a baseline on first run and only flags subsequently unseen reports.
- Repeated identical observations do not create duplicate history.
- Revised observations append a new revision and preserve the prior value.
- Recommendation snapshots are content-addressed; rebuilding unchanged content does not create duplicate snapshots.

## Security controls

- HTTPS-only external URLs.
- localhost, private, reserved, link-local and similar IP targets are rejected.
- redirect targets are revalidated.
- response body size is limited before and after gzip decompression.
- discovery patterns use a restricted literal + `.*` wildcard language, not arbitrary regex.
- externally sourced text is displayed through the existing safe DOM/text-content rendering patterns.
- no runtime admin endpoint exists; administrative authority is GitHub repository write permission.

## Remaining production gates

These cannot be truthfully marked passed inside this environment:

1. Run the scheduled workflow on an actual public GitHub repository.
2. Confirm GitHub-hosted runners can reach each configured source.
3. Confirm Eurostat returns the expected current JSON-stat shape through the live collector.
4. Confirm explicit GitHub Pages artifact deployment succeeds.
5. Run Playwright/browser smoke tests against the deployed `github.io` URL on desktop and mobile.
6. Observe at least several scheduled cycles and review source-specific blocks/timeouts.

These are deployment/integration risks, not reasons to redesign the architecture.
