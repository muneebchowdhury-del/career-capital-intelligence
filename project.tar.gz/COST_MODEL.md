# Cost model

## Required recurring cost: $0

Default production path:

- GitHub public repository — free.
- Standard GitHub-hosted Actions for public repositories — free.
- GitHub Pages for a public repository — free.
- SQLite — local/open-source, no service charge.
- Public official data sources — no paid feed required for the current source registry.

## Deliberately excluded

- Cloudflare D1/Workers as a dependency
- paid database hosting
- paid cron/scheduler
- paid web-search API
- paid job-market API
- custom domain
- proprietary queue service

## Future rule

A new data source may only become a required production dependency if there is a zero-cost path or the user explicitly changes the $0 constraint. Paid sources can be treated as optional enhancements, never a prerequisite.
